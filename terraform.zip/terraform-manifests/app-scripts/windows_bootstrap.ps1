#####
## Installing Prerequisites
#####
Start-Transcript -Path C:\customscript-$(get-date -uFormat "%m%d%Y%H%MS").log

#Enable ports 80 & 443 on windows firewall for communication
if (-Not (Get-NetFirewallRule -DisplayName "Allow Inbound Port 80 and 443").Enabled -eq $True) {
    New-NetFirewallRule -DisplayName "Allow Inbound Port 80 and 443" -Direction Inbound -LocalPort 80,443 -Protocol TCP -Action Allow -Profile Public
}

# Mandatory parameters passed dynamically from resource: azurerm_virtual_machine_scale_set_extension.windows_bootstrap.
$AzureKeyVault_Name=$args[0]
$AzureKeyVault_Cert_Name=$args[1]
$AzureKeyVault_Cert_Password=$args[2]

# Install Chocolatey & Enable auto-confirmation globally
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
C:\ProgramData\chocolatey\bin\choco.exe feature enable -n allowGlobalConfirmation

# Install Nginx
# Note: nginx is installed in the C:\tools directory by default. For the sake of POC we're not changing the installation directory.
# Pinned latest version to avoid automation challenges
C:\ProgramData\chocolatey\bin\choco.exe install nginx --version 1.21.6

# Install Azure Powershell
C:\ProgramData\chocolatey\bin\choco.exe install az.powershell

# Install Openssl
C:\ProgramData\chocolatey\bin\choco.exe install openssl

# Get the certificate password from Azure Key Vault Secrets (Next Phase)
$Response = Invoke-RestMethod -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net' -Method GET -Headers @{Metadata="true"}
$KeyVaultToken = $Response.access_token
# $cert_password = (Invoke-RestMethod -Uri "https://$AzureKeyVault_Name.vault.azure.net/secrets/$AzureKeyVault_Cert_Secret_Name?api-version=2016-10-01" -Method GET -Headers @{Authorization="Bearer $KeyVaultToken"}).value
# $cert_password = $AzureKeyVault_Cert_Password

# Export the certificate from Azure Key Vault to a local file
Connect-AzAccount -Identity
$cert = Get-AzKeyVaultCertificate -VaultName "$AzureKeyVault_Name" -Name "$AzureKeyVault_Cert_Name"
$secret = Get-AzKeyVaultSecret -VaultName "$AzureKeyVault_Name" -Name $cert.Name
$secretValueText = '';
$ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret.SecretValue)
try {
    $secretValueText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
} finally {
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
}
$secretByte = [Convert]::FromBase64String($secretValueText)
$x509Cert = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
$x509Cert.Import($secretByte, "", "Exportable,PersistKeySet")
$type = [System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx
$pfxFileByte = $x509Cert.Export($type, "$AzureKeyVault_Cert_Password")
# Write to a file
[System.IO.File]::WriteAllBytes("C:\tools\KeyVault.pfx", $pfxFileByte)

C:\Progra~1\OpenSSL-Win64\bin\openssl.exe pkcs12 -in C:/tools/KeyVault.pfx -clcerts -nokeys -out C:/tools/nginx.pem -password pass:$AzureKeyVault_Cert_Password
C:\Progra~1\OpenSSL-Win64\bin\openssl.exe pkcs12 -in C:/tools/KeyVault.pfx -nocerts -nodes -out C:/tools/nginx.key -password pass:$AzureKeyVault_Cert_Password

# Update nginx configuration file to accept https communication with port and certificate file
$nginx_conf_path = "C:\tools\nginx-1.21.6\conf\nginx.conf"
$https_conf_lines = "        listen       443 ssl;`n        ssl_certificate `t C:/tools/nginx.pem;`n        ssl_certificate_key `t C:/tools/nginx.key;"
$original_file_contents = Get-Content ($nginx_conf_path) -Raw

if (-Not $original_file_contents.Contains($https_conf_lines)){
    $Match = [regex]::Escape("        listen       80;")
    $NewLine = $https_conf_lines
    $Content = Get-Content $nginx_conf_path
    $Index = ($content | Select-String -Pattern $Match).LineNumber + 1
    $NewContent = @()
    0..($Content.Count-1) | Foreach-Object {
        if ($_ -eq $index) {
            $NewContent += $NewLine
        }
        $NewContent += $Content[$_]
    }

    $Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
    [System.IO.File]::WriteAllLines($nginx_conf_path, $NewContent, $Utf8NoBomEncoding)
}

# Uninstall Packages
C:\ProgramData\chocolatey\bin\choco.exe uninstall openssl
C:\ProgramData\chocolatey\bin\choco.exe uninstall az.powershell

# Restart Nginx services
Restart-Service nginx -Force
